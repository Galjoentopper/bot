# lightgbm_BTCEUR_v20250828_182213

## Model Information
- **Type**: LIGHTGBM
- **Symbol**: BTCEUR
- **Version**: v20250828_182213
- **Created**: 2025-08-28T18:22:13.098056
- **Training Machine**: pkrvmccyg1gnepe

## Performance Metrics
{}

## Dependencies
{
  "python": "3.12.3 (main, Aug 14 2025, 17:47:21) [GCC 13.3.0]",
  "platform": "Linux-6.11.0-1018-azure-x86_64-with-glibc2.39",
  "architecture": "64bit",
  "torch": "2.8.0+cu128",
  "lightgbm": "4.6.0",
  "numpy": "1.26.4",
  "pandas": "2.3.2",
  "scikit-learn": "1.7.1"
}

## Feature Columns (0)
[]

## Training Configuration
{
  "data": {
    "symbols": [
      "BTCEUR",
      "ETHEUR",
      "ADAEUR"
    ],
    "interval": "30m",
    "lookback_days": 365,
    "validation_split": 0.2,
    "test_split": 0.1
  },
  "trainer": {
    "symbols": [
      "BTCEUR",
      "ETHEUR",
      "ADAEUR"
    ],
    "interval": "30m",
    "target_type": "return",
    "default_target_horizon": 1,
    "n_splits": 5,
    "embargo": 100,
    "fee_bps": 10.0,
    "optuna_trials": 100,
    "default_models": [
      "gru",
      "lightgbm",
      "ppo"
    ]
  },
  "training": {
    "cv_splits": 5,
    "embargo_period": 24,
    "max_workers": 8,
    "batch_size": 512,
    "epochs": 100,
    "early_stopping_patience": 10,
    "optuna_trials": 100,
    "optuna_timeout": 7200,
    "memory_limit": "16GB",
    "gpu_enabled": true,
    "gpu_memory_fraction": 0.8
  },
  "models": {
    "lightgbm": {
      "enabled": true,
      "params": {
        "objective": "regression",
        "metric": "rmse",
        "boosting_type": "gbdt",
        "num_leaves": 31,
        "learning_rate": 0.05,
        "feature_fraction": 0.9,
        "bagging_fraction": 0.8,
        "bagging_freq": 5,
        "verbose": -1,
        "n_estimators": 1000,
        "early_stopping_rounds": 50
      }
    },
    "gru": {
      "enabled": true,
      "params": {
        "hidden_size": 128,
        "num_layers": 3,
        "dropout": 0.2,
        "learning_rate": 0.001,
        "batch_size": 512,
        "sequence_length": 60,
        "epochs": 100
      }
    },
    "ppo": {
      "enabled": true,
      "params": {
        "learning_rate": 0.0003,
        "n_steps": 2048,
        "batch_size": 64,
        "n_epochs": 10,
        "gamma": 0.99,
        "gae_lambda": 0.95,
        "clip_range": 0.2,
        "ent_coef": 0.01,
        "vf_coef": 0.5,
        "max_grad_norm": 0.5,
        "total_timesteps": 100000
      }
    }
  },
  "features": {
    "technical_indicators": true,
    "price_features": true,
    "volume_features": true,
    "volatility_features": true,
    "momentum_features": true,
    "trend_features": true,
    "statistical_features": true,
    "fourier_features": true,
    "wavelet_features": true,
    "fractal_features": true,
    "entropy_features": true,
    "feature_selection": true,
    "max_features": 200,
    "selection_method": "mutual_info"
  },
  "trading": {
    "initial_balance": 10000,
    "max_position_size": 0.1,
    "transaction_fee": 0.001,
    "slippage": 0.0005,
    "stop_loss": 0.02,
    "take_profit": 0.04,
    "max_drawdown": 0.1
  },
  "output": {
    "base_dir": "models",
    "save_models": true,
    "save_metadata": true,
    "save_features": true,
    "save_preprocessors": true,
    "create_packages": true,
    "create_transfer_bundle": true,
    "package_compression": "zip",
    "version_models": true,
    "keep_versions": 5
  },
  "logging": {
    "level": "INFO",
    "file": "logs/training.log",
    "max_size": "100MB",
    "backup_count": 5,
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  },
  "mlflow": {
    "enabled": true,
    "tracking_uri": "./mlruns",
    "experiment_name": "trading_models"
  },
  "notifications": {
    "telegram": {
      "enabled": true,
      "bot_token": "7733436451:AAH6Sls8uL4fEgd6Ty7VEKSBIMauhaVkN4c",
      "chat_id": "7988790407"
    }
  },
  "monitoring": {
    "enabled": true,
    "metrics_interval": 300,
    "save_metrics": true
  },
  "environment": {
    "type": "training",
    "machine_id": "training-pc",
    "python_version": "3.9+",
    "required_memory": "8GB",
    "recommended_memory": "16GB",
    "gpu_required": false,
    "gpu_recommended": true
  }
}

## Notes


## Usage
This package can be imported using the ModelPackager.import_model() method.
