#!/usr/bin/env python3
"""
Model Import Script
Automatically import all models from a transfer bundle
"""

import json
import sys
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from src.utils.model_packaging import ModelPackager

def main():
    packager = ModelPackager()
    
    # Read bundle info
    with open("bundle_info.json", "r") as f:
        bundle_info = json.load(f)
    
    print(f"Importing {len(bundle_info['packages'])} models...")
    
    for pkg_info in bundle_info["packages"]:
        print(f"Importing {pkg_info['name']}...")
        try:
            result = packager.import_model(pkg_info["file"])
            print(f"  ✓ Imported to: {list(result.values())[0]}")
        except Exception as e:
            print(f"  ✗ Error: {e}")
    
    print("Import complete!")

if __name__ == "__main__":
    main()
